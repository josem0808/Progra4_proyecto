﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace FundaVida
{
    public partial class telfAgregar : System.Web.UI.Page
    {
        SqlConnection cnx; 
        SqlCommand cmd; 
        SqlDataReader dr;
        SqlDataAdapter sda;
        private bool establecerConexion()
        {

            try
            {
                cnx = new SqlConnection();
                cnx.ConnectionString = ConfigurationManager.ConnectionStrings["conexionProduccion"].ConnectionString;
                cnx.Open();
                if (cnx.State == ConnectionState.Open)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {

                return false;
            }
        }

        public void agregarTefl()
        {

            try
            {
                String query = "insert into Telefono (Numero_telefono, Persona_idPersona, Activo) values (@Numero_telefono, @Persona_idPersona, @Activo)";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Numero_telefono", Convert.ToInt32(txtnumTelf.Text));
                cmd.Parameters.AddWithValue("@Persona_idPersona", Convert.ToInt32(txtTelfced.Text));
                cmd.Parameters.AddWithValue("@Activo", checkActi.Checked);
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {

                throw;
            }
           
        


        }



        protected void Page_Load(object sender, EventArgs e)
        {




        }

        protected void btnAgrTe_Click(object sender, EventArgs e)
        {
                 agregarTefl();
        }
    }
}