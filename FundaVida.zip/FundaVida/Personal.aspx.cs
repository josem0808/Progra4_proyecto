﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace FundaVida
{
    public partial class Personal : System.Web.UI.Page
    {
        #region "Variables globales"
        SqlConnection cnx; //Declarando el objeto no lo inicializo
        SqlCommand cmd; //Declarado
        SqlDataReader dr;
        SqlDataAdapter sda;
        #endregion

        #region "Metodos globales"
        private bool establecerConexion()
        {
            try
            {
                cnx = new SqlConnection();
                cnx.ConnectionString = ConfigurationManager.ConnectionStrings["conexionProduccion"].ConnectionString;
                cnx.Open();
                if (cnx.State == ConnectionState.Open)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {

                return false;
            }
        }

        public void ingresarPersona()
        {
            try
            {
                String query = "INSERT INTO Personal(Persona_idPersona,Fecha_ingreso,Activo)" +
                "VALUES(@Persona_idPersona, @Fecha_ingreso, @Activo)";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Persona_idPersona", Convert.ToInt32(txtCedula.Text));
                cmd.Parameters.AddWithValue("@Fecha_ingreso", Convert.ToDateTime(caleFecha.SelectedDate));
                cmd.Parameters.AddWithValue("@Activo", cbActivo.Checked);
                cmd.ExecuteNonQuery();

                Session["prueba"] = "Se agrego el nuevo alumno correctamente";
                lblVa.Text = (String)Session["prueba"];

            }
            catch (Exception e)
            {

                Session["prueba"] = "Debe ingresar todos los datos";
                lblVa.Text = (String)Session["prueba"];
            }
            

        }

        public void cargarPersona()
        {

            try
            {
                establecerConexion();
                SqlDataAdapter da = new SqlDataAdapter("SELECT P.idPersona, P.Nombre, P.Apellido1, P.Apellido2, PP.Activo, PP.Fecha_ingreso FROM Personal PP JOIN persona P on P.idPersona = PP.Persona_idPersona", cnx);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.gVDatos.DataSource = dt;
                gVDatos.DataBind();

            }
            catch (Exception e)
            {

                lblVa.Text = e.ToString();
            }
            
        }

        public void buscarPersona()
        {

            try
            {
                establecerConexion();
                SqlDataAdapter da = new SqlDataAdapter("SELECT P.idPersona, P.Nombre, P.Apellido1, P.Apellido2, PP.Activo, PP.Fecha_ingreso FROM Personal PP JOIN persona P on P.idPersona = PP.Persona_idPersona where idPersona LIKE'" + txtBuscar.Text + "%'", cnx);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.gVDatos.DataSource = dt;
                gVDatos.DataBind();

            }
            catch (Exception e)
            {

                lblVa.Text = e.ToString();
            }
            

        }

        public void Eliminar()
        {

            try
            {
                String query = "DELETE FROM Personal WHERE Persona_idPersona = @Persona_idPersona";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Persona_idPersona", txtCedula.Text);
                cmd.ExecuteNonQuery();
                cnx.Close();

            }
            catch (Exception e)
            {

                lblVa.Text = e.ToString();
            }
            
        }

        public void Editar()
        {
            try
            {
                String query = "UPDATE Personal SET Fecha_ingreso = @Fecha_ingreso , Activo = @Activo  WHERE Persona_idPersona = @Persona_idPersona ";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Persona_idPersona", Convert.ToInt32(txtCedula.Text));
                cmd.Parameters.AddWithValue("@Fecha_ingreso", Convert.ToDateTime(caleFecha.SelectedDate));
                cmd.Parameters.AddWithValue("@Activo", cbActivo.Checked);
                cmd.ExecuteNonQuery();
                cnx.Close();

            }
            catch (Exception e)
            {

                lblVa.Text = e.ToString();
            }
            
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            ingresarPersona();
        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {
            cargarPersona();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            buscarPersona();
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            Eliminar();
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            Editar();
        }
    }
}