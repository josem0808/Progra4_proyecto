﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;

namespace FundaVida
{
    public partial class Voluntario : System.Web.UI.Page
    {

        #region "Variables globales"
        SqlConnection cnx; //Declarando el objeto no lo inicializo
        SqlCommand cmd; //Declarado
        SqlDataReader dr;
        SqlDataAdapter sda;
        #endregion



        #region "Variables globales"
        private bool establecerConexion()
        {
            try
            {
                cnx = new SqlConnection();
                cnx.ConnectionString = ConfigurationManager.ConnectionStrings["conexionProduccion"].ConnectionString;
                cnx.Open();
                if (cnx.State == ConnectionState.Open)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception)
            {

                return false;
            }
        }


        public void ingresarVoluntario()
        {
            try
            {
                String query = "INSERT INTO Voluntario(Persona_idPersona,Fecha_ingreso,Activo)" +
                "VALUES(@Persona_idPersona, @Fecha_ingreso, @Activo)";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Persona_idPersona", Convert.ToInt32(txtCedula.Text));
                cmd.Parameters.AddWithValue("@Fecha_ingreso", Convert.ToDateTime(caleFecha.SelectedDate));
                cmd.Parameters.AddWithValue("@Activo", cbActivo.Checked);
                cmd.ExecuteNonQuery();

                Session["prueba"] = "Se agrego el nuevo alumno correctamente";
                lblValidacion.Text = (String)Session["prueba"];

            }
            catch (Exception e)
            {
                Session["prueba"] = "Debe ingresar todos los datos";
                lblValidacion.Text = (String)Session["prueba"];

            }
            

        }

        public void cargarVoluntario()
        {

            try
            {
                establecerConexion();
                SqlDataAdapter da = new SqlDataAdapter("SELECT P.idPersona, P.Nombre, P.Apellido1, P.Apellido2, V.Activo, V.Fecha_ingreso FROM Voluntario V JOIN persona P on P.idPersona = V.Persona_idPersona", cnx);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.gVDatos.DataSource = dt;
                gVDatos.DataBind();

            }
            catch (Exception e)
            {

                lblValidacion.Text = e.ToString();
            }
           
        }

        public void buscarVoluntario()
        {

            try
            {
                establecerConexion();
                SqlDataAdapter da = new SqlDataAdapter("SELECT P.idPersona, P.Nombre, P.Apellido1, P.Apellido2, V.Activo, V.Fecha_ingreso FROM Voluntario V JOIN persona P on P.idPersona = V.Persona_idPersona where idPersona LIKE'" + txtBuscar.Text + "%'", cnx);
                DataTable dt = new DataTable();
                da.Fill(dt);
                this.gVDatos.DataSource = dt;
                gVDatos.DataBind();

            }
            catch (Exception e)
            {

                lblValidacion.Text = e.ToString();
            }
            

        }

        public void Eliminar()
        {

            try
            {
                String query = "DELETE FROM Voluntario WHERE Persona_idPersona = @Persona_idPersona";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Persona_idPersona", txtCedula.Text);
                cmd.ExecuteNonQuery();
                cnx.Close();

            }
            catch (Exception e)
            {

                lblValidacion.Text = e.ToString();
            }
            
        }

        public void Editar()
        {

            try
            {
                String query = "UPDATE Voluntario SET Fecha_ingreso = @Fecha_ingreso , Activo = @Activo  WHERE Persona_idPersona = @Persona_idPersona ";
                establecerConexion();
                cmd = new SqlCommand(query, cnx);
                cmd.Parameters.AddWithValue("@Persona_idPersona", Convert.ToInt32(txtCedula.Text));
                cmd.Parameters.AddWithValue("@Fecha_ingreso", caleFecha.SelectedDate);
                cmd.Parameters.AddWithValue("@Activo", cbActivo.Checked);
                cmd.ExecuteNonQuery();
                cnx.Close();

            }
            catch (Exception e)
            {

                lblValidacion.Text = e.ToString();
            }
            
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            ingresarVoluntario();
        }

        protected void btnRefrescar_Click(object sender, EventArgs e)
        {
            cargarVoluntario();
        }

        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            buscarVoluntario();
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            Eliminar();
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            Editar();
        }
    }
}